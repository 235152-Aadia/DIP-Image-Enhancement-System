import cv2
import numpy as np
import matplotlib.pyplot as plt
import os

# Create output folder
os.makedirs("images/output", exist_ok=True)

# -------------------------------
# Lab 01: Image Acquisition
# -------------------------------
def load_image(path):
    return cv2.imread(path)

def convert_to_grayscale(img):
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

def image_info(img):
    print("Shape (Resolution):", img.shape)
    print("Data Type:", img.dtype)
    print("Sample Matrix:\n", img[:5, :5])


# -------------------------------
# Lab 02: Sampling & Quantization
# -------------------------------
def sampling(img):
    return {
        "0.25": cv2.resize(img, None, fx=0.25, fy=0.25),
        "0.5": cv2.resize(img, None, fx=0.5, fy=0.5),
        "1.0": img,
        "1.5": cv2.resize(img, None, fx=1.5, fy=1.5),
        "2.0": cv2.resize(img, None, fx=2, fy=2),
    }

def quantization(img):
    return {
        "8-bit": img,
        "4-bit": (img // 16) * 16,
        "2-bit": (img // 64) * 64,
    }


# -------------------------------
# Lab 03: Transformations
# -------------------------------
def rotate_image(img, angle):
    h, w = img.shape
    matrix = cv2.getRotationMatrix2D((w//2, h//2), angle, 1)
    return cv2.warpAffine(img, matrix, (w, h))

def translate_image(img, x, y):
    h, w = img.shape
    matrix = np.float32([[1, 0, x], [0, 1, y]])
    return cv2.warpAffine(img, matrix, (w, h))

def shear_image(img):
    h, w = img.shape
    matrix = np.float32([[1, 0.5, 0], [0, 1, 0]])
    return cv2.warpAffine(img, matrix, (w, h))


# -------------------------------
# Lab 04: Intensity Transformations
# -------------------------------
def negative(img):
    return 255 - img

def log_transform(img):
    return np.uint8(255 * np.log(1 + img) / np.log(256))

def gamma_correction(img, gamma):
    return np.uint8(255 * (img / 255) ** gamma)


# -------------------------------
# Lab 05: Histogram Processing
# -------------------------------
def plot_histogram(img, title):
    plt.figure()
    plt.title(title)
    plt.hist(img.ravel(), bins=256)
    plt.show()

def histogram_equalization(img):
    return cv2.equalizeHist(img)


# -------------------------------
# Analysis Function
# -------------------------------
def analyze_image(img):
    mean_val = np.mean(img)
    std_val = np.std(img)

    print("\n--- Image Analysis ---")
    print("Brightness (Mean):", round(mean_val, 2))
    print("Contrast (Std Dev):", round(std_val, 2))

    return mean_val, std_val


# -------------------------------
# ✅ IMPROVED FINAL PIPELINE
# -------------------------------
def process_image(img):
    gray = convert_to_grayscale(img)

    # Step 1: Mild gamma correction (avoid over-brightening)
    gamma = gamma_correction(gray, 0.9)

    # Step 2: CLAHE (adaptive contrast enhancement)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    enhanced = clahe.apply(gamma)

    # Step 3: Light sharpening (improves text clarity)
    kernel = np.array([[0, -1, 0],
                       [-1, 5, -1],
                       [0, -1, 0]])
    sharpened = cv2.filter2D(enhanced, -1, kernel)

    return sharpened


# -------------------------------
# Display Function
# -------------------------------
def show_images(images_dict, title):
    n = len(images_dict)
    cols = 3
    rows = int(np.ceil(n / cols))

    plt.figure(figsize=(12, 4 * rows))

    for i, (name, img) in enumerate(images_dict.items()):
        plt.subplot(rows, cols, i + 1)
        plt.imshow(img, cmap='gray')
        plt.title(name)
        plt.axis('off')

    plt.suptitle(title)
    plt.tight_layout()
    plt.show()


# -------------------------------
# MAIN FUNCTION
# -------------------------------
def main():
    img = load_image("images/input.png")

    if img is None:
        print("❌ Image not found!")
        return

    print("\n--- Image Info ---")
    image_info(img)

    gray = convert_to_grayscale(img)

    # ---------------- Sampling ----------------
    samples = sampling(gray)
    show_images(samples, "Sampling Comparison")

    for name, im in samples.items():
        cv2.imwrite(f"images/output/sample_{name}.png", im)

    # ---------------- Quantization ----------------
    quant = quantization(gray)
    show_images(quant, "Quantization Comparison")

    for name, im in quant.items():
        cv2.imwrite(f"images/output/quant_{name}.png", im)

    # ---------------- Transformations ----------------
    angles = [30, 45, 60, 90, 120, 150, 180]
    rotations = {f"{a}°": rotate_image(gray, a) for a in angles}
    show_images(rotations, "Rotations")

    translated = translate_image(gray, 50, 30)
    sheared = shear_image(gray)

    cv2.imwrite("images/output/translated.png", translated)
    cv2.imwrite("images/output/sheared.png", sheared)

    # ---------------- Intensity ----------------
    intensity = {
        "Negative": negative(gray),
        "Log": log_transform(gray),
        "Gamma 0.5": gamma_correction(gray, 0.5),
        "Gamma 1.5": gamma_correction(gray, 1.5)
    }

    show_images(intensity, "Intensity Transformations")

    # ---------------- Histogram ----------------
    plot_histogram(gray, "Original Histogram")

    equalized = histogram_equalization(gray)
    plot_histogram(equalized, "Equalized Histogram")

    plt.figure(figsize=(8,4))
    plt.subplot(1,2,1)
    plt.imshow(gray, cmap='gray')
    plt.title("Before")

    plt.subplot(1,2,2)
    plt.imshow(equalized, cmap='gray')
    plt.title("After Equalization")
    plt.show()

    # ---------------- Final Enhancement ----------------
    print("\n=== BEFORE ===")
    orig_mean, orig_std = analyze_image(gray)

    final = process_image(img)

    print("\n=== AFTER ===")
    final_mean, final_std = analyze_image(final)

    print("\n--- IMPROVEMENT ---")
    print("Brightness Change:", round(final_mean - orig_mean, 2))
    print("Contrast Change:", round(final_std - orig_std, 2))

    cv2.imwrite("images/output/final.png", final)

    plt.figure(figsize=(8,4))
    plt.subplot(1,2,1)
    plt.imshow(gray, cmap='gray')
    plt.title("Original")

    plt.subplot(1,2,2)
    plt.imshow(final, cmap='gray')
    plt.title("Final Enhanced")
    plt.show()


# Run
if __name__ == "__main__":
    main()